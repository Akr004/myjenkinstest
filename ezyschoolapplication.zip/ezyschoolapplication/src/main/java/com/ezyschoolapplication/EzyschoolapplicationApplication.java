package com.ezyschoolapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EzyschoolapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(EzyschoolapplicationApplication.class, args);
	}

}
